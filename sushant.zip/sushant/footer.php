<section class="footer_widgets">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="wid_descrpt widget">
                        <img src="img/logo.png" alt=""/>
                        <p>Infosys demonstrated to he world indi an company could impleme ards of quality, operations.</p>
                        <p>That compare with the best.That I am happy with infosys demon the war.</p>
                    </div><!--/.widget-->
                </div>
                <div class="col-md-3 offset-md-1">
                    <div class="wid_contact widget">
                        <h3>Contact Us</h3>
                        <p>Address: 10/2, West Wall, 5600 Street, New York, USA<br>
                        Phone: +44 8858 6656<br>
                    Email: address@domain.com</p>
                    </div><!--/.widget-->
                </div>
                <div class="col-md-2">
                    <div class="wid_menu widget">
                        <h3>Company</h3>
                        <ul>
                            <li><a href="#">Support</a></li>
                            <li><a href="#">Blog</a></li>
                            <li><a href="#">Privacy & Policy</a></li>
                            <li><a href="#">Terms & Conditions</a></li>
                        </ul>
                    </div><!--/,widget-->
                </div>
                <div class="col-md-3">
                    <div class="wid_newsletter widget">
                        <h3>Subscribe For Newsletter</h3>
                        <form>
                            <input type="email" placeholder="Email Address"/>
                            <button type="submit" class="btn"><i class="fas fa-paper-plane"></i></button>
                        </form>
                    </div><!--/.widget-->
                </div>
            </div>
        </div><!--/.container-->
    </section>

 <footer class="footers">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="copyright_text">
                        <p>&copy; 2018 XeroTheme.All Rigts Reserved</p>
                    </div>
                </div>
                <div class="col-md-6">
                    <ul class="footer_social">
                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fab fa-pinterest-p"></i></a></li>
                        <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
        </div><!--/.container-->
    </footer>